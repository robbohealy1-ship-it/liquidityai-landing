# Liquidity AI+ Landing Page

This is a single-file landing page for **Liquidity AI+** (signals + AI risk manager + trade copier).

## Quick Deploy to GitHub Pages (Step-by-Step)

### Option A — Project Site (recommended)
1. Create a new public repo on GitHub, e.g. `liquidityai-landing`.
2. Upload `index.html` to the root of the repo (drag-and-drop on GitHub works).
3. Go to **Settings → Pages**.
4. Under **Source**, choose **Deploy from a branch**.
5. Select **Branch: `main`** and **Folder: `/ (root)`** → click **Save**.
6. Wait ~1–3 minutes. Your site will be live at:
   ```
   https://YOUR-USERNAME.github.io/liquidityai-landing/
   ```

### Option B — User Site (root domain on GitHub)
1. Create a repo named **`YOUR-USERNAME.github.io`** (must be exact).
2. Upload `index.html` to the root.
3. Go to **Settings → Pages** and ensure the source is **main / root**.
4. Your site will be live at:
   ```
   https://YOUR-USERNAME.github.io
   ```

## Customize
- Replace all `#` links on buttons with your **waitlist link** (Google Form, Mailchimp, etc.).
- Update email in footer: `info@liquidityai.io`.
- Add images to `/assets` and link them in `index.html` if needed.

## Custom Domain (Optional)
1. Buy a domain (e.g., `liquidityai.io`). 
2. In the repo, go to **Settings → Pages** → **Custom domain** → enter your domain.
3. At your domain registrar, create a **CNAME** DNS record pointing to `YOUR-USERNAME.github.io`.
4. Wait for DNS to propagate.

## Troubleshooting
- **404 / Not found:** Ensure your `index.html` is in the repo **root** and Pages is set to `main / root`.
- **No styles:** Keep CSS inline (as in this file) or ensure correct relative paths.
- **Slow updates:** GitHub Pages can cache; wait a couple of minutes then hard-refresh.

---

Happy shipping!
